<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
//tao chuoi luu cau lenh sql
$sql = "SELECT * FROM student";
//thuc thi cau lenh sql va dua doi tuong vao $result
$result = $conn->query($sql);


if ($result->num_rows > 0) {
  
  
  //cach 1: show du lieu nhu bien
  //show gia tri trong mang
	print_r ($result);
	echo '<br>';
	echo '<br>';
	
  //Cach 2: show theo tung dong voi for
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"]. " - Hoten: " . $row["fullname"]. " " . $row["email"].' ngaysinh: '.$row['Birthday']. "<br>";
  }
  echo '<br>';
  echo '<br>';
  //xoa ket qua cu tu o tren
  $result -> free_result();
  
  
  //Cach 3: trinh bay voi bang html
  //load du lieu moi len dua vao bien result
  $result = $conn->query($sql);
  $result_all = $result -> fetch_all();
  print_r($result_all);
  // trinh bay du lieu trong 1 bang html
  //tieu de bang
    echo "<table border=1><tr><th>ID</th><th>Hoten</th><th>email</th><th>ngaysinh</th></tr>";
    // output data of each row
    foreach ($result_all as $row) {
//dinh dang de hien thi ngay thang theo dd-mm-yyyy
		$date = date_create($row[3]);
        echo "<tr><td>" . $row[0]. "</td><td>" . $row[1]. "</td><td>" . $row[2]. "</td><td>" . 
		$date ->format('d-m-Y')
		. "</td></tr>";
    }
   echo "</table>";
  
} else {
  echo "0 ket qua tra ve";
}
$conn->close();

//Cach 4 mysqli hướng thủ tục
echo "<br>Cách 4 - sd Mysqli hướng thủ tục với phương thức mysqli_fetch_assoc():<br>";
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
//tao chuoi luu cau lenh sql
$sql = "SELECT * FROM student";
//thuc thi cau lenh sql va dua doi tuong vao $result
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // hiển thị dữ liệu trên trang
    while($row = mysqli_fetch_assoc($result)) {
        echo "id: " . $row["id"]. " - Hoten: " . $row["fullname"]. " " 
        . $row["email"].' ngaysinh: '.$row['Birthday']."<br>";
    }
} else {
    echo "0 results";
}

mysqli_close($conn);

echo "<br>";
//Cach 5 sử dụng PDO
echo "Sử dụng PDO";
echo "<table style='border: solid 1px black;'>";
echo "<tr><th>Id</th><th>Firstname</th><th>Lastname</th></tr>";
 
class TableRows extends RecursiveIteratorIterator { 
    function __construct($it) { 
        parent::__construct($it, self::LEAVES_ONLY); 
    }
 
    function current() {
        return "<td style='width:150px;border:1px solid black;'>"
            . parent::current(). "</td>";
    }
 
    function beginChildren() { 
        echo "<tr>"; 
    } 
 
    function endChildren() { 
        echo "</tr>" . "\n";
    } 
} 
 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";
 
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT id, fullname, email FROM student"); 
    $stmt->execute();
 
    // thiết lập mảng kết quả thành mảng kết hợp
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC); 
    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";



?>
