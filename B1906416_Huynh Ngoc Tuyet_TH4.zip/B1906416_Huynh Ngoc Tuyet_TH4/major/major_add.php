<!DOCTYPE HTML>
<html>  
<body>

<form action="major_save.php" method="post">
Major ID: <input type="text" name="id_major"><br>
Major's name: <input type="text" name="name_major"><br>
<input type="submit">
</form>

</body>
</html>
