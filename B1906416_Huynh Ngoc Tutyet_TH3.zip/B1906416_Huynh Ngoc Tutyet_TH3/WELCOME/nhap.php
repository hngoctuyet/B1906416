<!DOCTYPE HTML>
<html>  
<body>

<form action="welcome.php" method="post">
Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
Password: <input type="password" name="psw"><br>
D.O.B: <input type="date" name="DOB"><br>
<input type="submit">
</form>
</body>
</html>
