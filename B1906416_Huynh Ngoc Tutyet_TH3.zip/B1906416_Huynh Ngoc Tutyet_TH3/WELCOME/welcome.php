<html>
<body>

Hello <?php echo $_POST["name"]; ?><br>
Your email address is: <?php echo $_POST["email"]; ?><br>
Your birthday is: <?php echo $_POST["DOB"] ;?><br>
Your password is: <?php echo $_POST["psw"];?><br>
</body>
</html>
