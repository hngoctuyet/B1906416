<?php
		
		function giaiThua(int $x){
		$giaithua = 1;
			for ( $i = 1; $i<=10; $i++) {
				$giaithua = $giaithua * $i;
			}
			return $giaithua;
		}
		echo giaiThua(10);

?>