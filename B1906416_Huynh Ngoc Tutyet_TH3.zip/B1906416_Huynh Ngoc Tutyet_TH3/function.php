<?php
declare(strict_types=0);
function addNumbers(int $a, int $b) {
  return $a + $b;
}
echo addNumbers(5, 10);
echo addNumbers(5, “so 10”);
?>