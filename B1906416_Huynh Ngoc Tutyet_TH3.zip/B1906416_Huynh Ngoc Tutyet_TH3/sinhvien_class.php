<?php
	class sinhVien {
		public $mssv;
		public $hoten;
		public $ngaysinh;
		
	//phuong thuc xay dung
		function __construct($mssv, $name, $dob) {
			$this->mssv = $mssv;
			$this->hoten = $name;
			$this->ngaysinh = $dob;
		}
		
	//phuong thuc huy
		function __destruct() {
    			echo "<br> Da xoa {$this->mssv}.";
 		 }
		
	//cac ham gan gia tri cho thuoc tinh
		function set_mssv($ms) {
			$this->mssv = $ms;
		}
	
		function set_hoten($name) {
			$this->hoten = $name;
		}
		
		function set_ngaysinh($dob) {
			$this->ngaysinh = $dob;
		}
		
	//Tra ve gia tri cua thuoc tinh
		 function get_hoten() {
    			return $this->hoten;
  		}
  		
  		function get_mssv() {
    			return $this->mssv;
  		}

  		function get_ngaysinh() {
    			return $this->ngaysinh;
  		}

		function get_tuoi() {
			return (date("y") - date("y",$this->ngaysinh));
		
		}
	}

//tao doi tuong ten Huynh Ngoc Tuyet, mssv b1906416
$sv = new sinhVien("b1906416", "Huynh Ngoc Tuyet", " ");
//gan ngay sinh cho Huynh Ngoc Tuyet
$sv->ngaysinh =  mktime(0, 0, 0, 10,3, 2001);
//In ra tuoi cua doi tuong
echo "Tuoi cua sinh vien ".$sv->hoten." la: ", date("y") - date("y",$sv->ngaysinh);
?>