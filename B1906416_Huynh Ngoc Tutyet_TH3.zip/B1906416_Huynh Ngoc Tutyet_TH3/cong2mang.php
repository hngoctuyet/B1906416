
<?php
	
	function cong2mang(array $m1, array $m2){
		$m1_length = count ($m1);
		$m2_length = count ($m2);
		if ($m1_length == $m2_length) {
			echo "Kết quả của phép cộng 2 mảng là: ";
			for($x = 0; $x < $m1_length; $x++) {
  			$sum[$x] = $m1[$x] + $m2[$x] ;}
  			foreach ($sum as $value){echo $value." ";}
  				}
		else echo "Lỗi do 2 mảng không có cùng độ dài";
	}
	$a=array(344,224,223,7737,9922,-828);
	$b=array(-344,-324,123,773,-9922,828);
	cong2mang ($a, $b);

?>